import org.jetbrains.compose.desktop.application.dsl.TargetFormat
import org.jetbrains.kotlin.gradle.ExperimentalWasmDsl
import org.jetbrains.kotlin.gradle.targets.js.webpack.KotlinWebpackConfig

plugins {
    id("java-library")
    alias(libs.plugins.kotlinMultiplatform)
    alias(libs.plugins.composeMultiplatform)
    alias(libs.plugins.composeCompiler)
}
kotlin {
    jvm("desktop")

    @OptIn(ExperimentalWasmDsl::class)
    wasmJs {
        browser()
    }

    sourceSets {
        val wasmJsMain by getting
        val commonMain by getting {
            dependencies {
                // Add common dependencies here
                implementation(project.dependencies.platform(libs.koin.bom))
                implementation(libs.koin.core)
                implementation(libs.koin.compose)
                implementation(libs.koin.composeVM)
                implementation(libs.retrofit2)
                implementation(libs.okhttp3.logging.interceptor)
                implementation(libs.kotlinx.coroutines.swing)
                implementation(libs.retrofit2.converter.gson)
                implementation(libs.okhttp3.sse)
                implementation(libs.okhttp3)
            }
        }
        wasmJsMain.dependencies {
            implementation(project.dependencies.platform(libs.koin.bom))
            implementation(libs.koin.core)
            implementation(libs.koin.compose)
            implementation(libs.koin.composeVM)
            implementation(libs.retrofit2)
            implementation(libs.okhttp3.logging.interceptor)
            implementation(libs.kotlinx.coroutines.swing)
            implementation(libs.retrofit2.converter.gson)
            implementation(libs.okhttp3.sse)
            implementation(libs.okhttp3)
        }
        val commonTest by getting {
            dependencies {
                implementation(kotlin("test"))
            }
        }
    }
}