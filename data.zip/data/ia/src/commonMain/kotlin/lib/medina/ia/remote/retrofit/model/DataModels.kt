package lib.medina.ia.remote.retrofit.model

import com.google.gson.annotations.SerializedName
import lib.medina.ia.remote.model.Content

data class GenerateContentResponse(
    @SerializedName("candidates") val candidates: List<Candidate>? = null,
    @SerializedName("promptFeedback") val promptFeedback: PromptFeedback? = null
)

data class Candidate(
    @SerializedName("content") val content: Content? = null,
    @SerializedName("finishReason") val finishReason: String? = null,
    @SerializedName("index") val index: Int? = null,
    @SerializedName("safetyRatings") val safetyRatings: List<SafetyRating>? = null
)

data class PromptFeedback(
    @SerializedName("safetyRatings") val safetyRatings: List<SafetyRating>? = null
)

data class SafetyRating(
    @SerializedName("category") val category: String? = null,
    @SerializedName("probability") val probability: String? = null
)

