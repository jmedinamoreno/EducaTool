package lib.medina.ia.remote.gemini
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import lib.medina.ia.remote.retrofit.service.GeminiService
import lib.medina.ia.repository.IARepository
import okhttp3.ResponseBody
import java.io.InputStream
import java.util.Locale


class GeminiAgent(
    var deviceLanguage: String? = Locale.getDefault().language
):IARepository {

    private var geminiService: GeminiService = lib.medina.ia.remote.retrofit.client.GeminiRetrofitClient.geminiService

    override fun generateContent(prompt: String): Flow<String?> = flow {
        val request = lib.medina.ia.remote.model.GenerateContentRequest(
            contents = listOf(
                lib.medina.ia.remote.model.Content(
                    parts = listOf(
                        lib.medina.ia.remote.model.Part(text = prompt)
                    )
                )
            )
        )
        try {
            val response = geminiService.generateContent(request = request)
            emit(response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text)
        } catch (e: Exception) {
            emit("Error: ${e.message}")
        }
    }

    override fun generateStreamedContent(prompt: String): Flow<String> = flow {
        val request = lib.medina.ia.remote.model.GenerateContentRequest(
            contents = listOf(
                lib.medina.ia.remote.model.Content(
                    parts = listOf(
                        lib.medina.ia.remote.model.Part(text = prompt)
                    )
                )
            )
        )
        val responseBody: ResponseBody = geminiService.streamGenerateContent(request = request)
        val inputStream: InputStream = responseBody.byteStream()
        try {
            val buffer = ByteArray(4096) // Read in 4KB chunks
            var bytesRead: Int
            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                val chunk = String(buffer, 0, bytesRead)
                emit(chunk)
            }
        } catch (e: Exception) {
            emit("Error: ${e.message}")
        } finally {
            inputStream.close()
            responseBody.close()
        }
    }
}