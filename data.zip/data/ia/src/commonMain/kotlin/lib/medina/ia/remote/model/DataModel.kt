package lib.medina.ia.remote.model

import com.google.gson.annotations.SerializedName

data class GenerateContentRequest(
    @SerializedName("system_instruction")
    val systemInstruction: SystemInstruction?=null,
    val contents: List<Content>
)

data class SystemInstruction(
    val parts: List<Part>
)

data class Content(
    val role: String? = null,
    val parts: List<Part>
)

data class Part(
    val text: String
)