package lib.medina.ia.repository
import kotlinx.coroutines.flow.Flow

interface IARepository {
    fun generateContent(prompt: String): Flow<String?>
    fun generateStreamedContent(prompt: String): Flow<String?>
}