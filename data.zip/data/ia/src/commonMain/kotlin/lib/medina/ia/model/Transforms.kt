package lib.medina.ia.model

