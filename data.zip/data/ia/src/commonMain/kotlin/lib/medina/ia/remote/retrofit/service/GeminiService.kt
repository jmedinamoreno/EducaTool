package lib.medina.ia.remote.retrofit.service

import lib.medina.ia.remote.model.GenerateContentRequest
import lib.medina.ia.remote.retrofit.model.GenerateContentResponse
import okhttp3.ResponseBody
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Streaming

private val modelName = "gemini-2.0-flash-lite"

interface GeminiService {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String = modelName,
        @Query("key") apiKey: String = "AIzaSyDDxZ1hsEFiiUaXkOkJ4kQLyLLDQS6hCXk",//BuildConfig.apiKey,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse

    @Streaming
    @POST("v1beta/models/{model}:streamGenerateContent?alt=sse")
    suspend fun streamGenerateContent(
        @Path("model") model: String = modelName,
        @Query("key") apiKey: String = "AIzaSyDDxZ1hsEFiiUaXkOkJ4kQLyLLDQS6hCXk",
        @Body request: GenerateContentRequest
    ): ResponseBody
}