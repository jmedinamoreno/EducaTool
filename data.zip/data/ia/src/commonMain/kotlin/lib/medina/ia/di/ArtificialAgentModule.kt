package lib.medina.ia.di

import lib.medina.ia.remote.gemini.GeminiAgent
import lib.medina.ia.repository.IARepository
import org.koin.dsl.module

val ArtificialIntelligenceModule = module {
    single<IARepository> { GeminiAgent() }
}