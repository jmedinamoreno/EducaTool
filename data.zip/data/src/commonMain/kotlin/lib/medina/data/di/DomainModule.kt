package lib.medina.data.di
import org.koin.dsl.module
import lib.medina.ia.di.ArtificialIntelligenceModule

val domainModule = module {
    includes(ArtificialIntelligenceModule)
}

